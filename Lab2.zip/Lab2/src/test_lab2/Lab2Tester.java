package test_lab2;

import static org.junit.Assert.*;

import org.junit.Test;

public class Lab2Tester {

	@Test
	public void test() {
		fail("Not yet implemented");
	}

}
