#!/bin/bash

declare -A borrowed_books

while IFS=: read -r book_id borrowed_count; do
    borrowed_books["$book_id"]=$borrowed_count
done < borrowed.txt

while IFS=: read -r book_id title author available_count; do
    borrowed_count=${borrowed_books["$book_id"]}
    
    if [[ -n "$borrowed_count" && "$borrowed_count" -gt "$available_count" ]]; then
        echo "$title"
    fi
done < books.txt

